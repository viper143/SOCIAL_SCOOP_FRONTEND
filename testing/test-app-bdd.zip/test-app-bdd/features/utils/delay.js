module.exports = {
  delay: 5000,
};
